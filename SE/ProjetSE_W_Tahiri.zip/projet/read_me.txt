Bonjour, pour lancer le programme faites make puis ./projet

Il faudra lancer au moins 2 fois le programme avec 2 utilisateurs différents par terminal afin de voir comment le système de messagerie marche.

Le rapport sera rendu plus tard.

Signé: Wissam Tahiri 
num Etudiant: 12105467
